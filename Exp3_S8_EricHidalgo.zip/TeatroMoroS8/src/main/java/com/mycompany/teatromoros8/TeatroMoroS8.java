/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teatromoros8;
import java.util.Scanner;

/**
 *
 * Eric Hidalgo S8
 */
public class TeatroMoroS8 {

    private Cliente[] clientes;
    private Asiento[] asientos;
    private Venta[] ventas;
    private Promocion[] promociones;

    private int ventasContador = 0;

    public TeatroMoroS8(int numClientes, int numAsientos, int numPromociones) {
        clientes = new Cliente[numClientes];
        asientos = new Asiento[numAsientos];
        ventas = new Venta[numAsientos];
        promociones = new Promocion[numPromociones];

        for (int i = 0; i < numAsientos; i++) {
            asientos[i] = new Asiento(i);
        }

        promociones[0] = new Promocion("Estudiante", 10);
        promociones[1] = new Promocion("Tercera Edad", 15);
    }

    public static void main(String[] args) {
        TeatroMoroS8 sistema = new TeatroMoroS8(100, 50, 2);
        sistema.menu();
    }

    public void menu() {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("\n--- Menu Principal ---");
            System.out.println("1. Registrar Cliente");
            System.out.println("2. Vender Entrada");
            System.out.println("3. Aplicar Descuento");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");
            while (!sc.hasNextInt()) {
                System.out.println("Por favor ingrese un numero valido");
                sc.next();
            }
            opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> registrarCliente();
                case 2 -> venderEntrada();
                case 3 -> aplicarDescuento();
                case 4 -> System.out.println("Saliendo...");
                default -> System.out.println("Opcion no valida");
            }
        } while (opcion != 4);
    }

    public void registrarCliente() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese ID del cliente: ");
        int id = sc.nextInt();
        System.out.print("Ingrese nombre del cliente: ");
        String nombre = sc.next();
        System.out.print("Ingrese tipo de cliente (Estudiante/Tercera Edad): ");
        String tipo = sc.next();

        clientes[id] = new Cliente(id, nombre, tipo);
        System.out.println("Cliente registrado exitosamente");
    }

    public void venderEntrada() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese ID del cliente: ");
        int clienteId = sc.nextInt();
        System.out.print("Ingrese ID del asiento: ");
        int asientoId = sc.nextInt();

        if (validarVenta(clienteId, asientoId)) {
            ventas[ventasContador++] = new Venta(ventasContador, clienteId, asientoId);
            asientos[asientoId].setDisponible(false);
            System.out.println("Venta realizada exitosamente");
        } else {
            System.out.println("Venta no realizada. Verifique los datos");
        }
    }

    public void aplicarDescuento() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese ID del cliente: ");
        int clienteId = sc.nextInt();
        System.out.print("Ingrese monto de la venta: ");
        double monto = sc.nextDouble();

        double montoConDescuento = calcularDescuento(clienteId, monto);
        System.out.println("El monto con descuento es: " + montoConDescuento);
    }

    private boolean validarVenta(int clienteId, int asientoId) {
        if (clienteId < 0 || clienteId >= clientes.length || clientes[clienteId] == null) {
            System.out.println("Cliente no valido");
            return false;
        }
        if (asientoId < 0 || asientoId >= asientos.length || !asientos[asientoId].isDisponible()) {
            System.out.println("Asiento no disponible");
            return false;
        }
        return true;
    }

    private double calcularDescuento(int clienteId, double monto) {
        Cliente cliente = clientes[clienteId];
        double descuento = 0;

        if (cliente.getTipo().equalsIgnoreCase("Estudiante")) {
            descuento = 10;
        } else if (cliente.getTipo().equalsIgnoreCase("Tercera Edad")) {
            descuento = 15;
        }

        return monto * (1 - descuento / 100);
    }
}
