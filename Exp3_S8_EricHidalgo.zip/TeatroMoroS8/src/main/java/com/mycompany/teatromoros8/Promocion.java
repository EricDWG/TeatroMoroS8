/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.teatromoros8;

/**
 *
 * Eric Hidalgo S8
 */
class Promocion {
    
    private final String tipo;
    private final int porcentaje;

    public Promocion(String tipo, int porcentaje) {
        this.tipo = tipo;
        this.porcentaje = porcentaje;
    }

    public String getTipo() {
        return tipo;
    }

    public int getPorcentaje() {
        return porcentaje;
    }
}
