/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.teatromoros8;

/**
 *
 * Eric Hidalgo S8
 */
class Venta {
    
    private final int idVenta;
    private final int idCliente;
    private final int idAsiento;

    public Venta(int idVenta, int idCliente, int idAsiento) {
        this.idVenta = idVenta;
        this.idCliente = idCliente;
        this.idAsiento = idAsiento;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public int getIdAsiento() {
        return idAsiento;
    }
}
